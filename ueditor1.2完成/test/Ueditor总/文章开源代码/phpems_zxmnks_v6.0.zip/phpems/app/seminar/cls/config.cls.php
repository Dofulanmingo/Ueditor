<?php
/*
 * Created on 2013-5-31
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
class config_content
{
	public $fields = array('seminarid','seminarcatid','seminartitle','seminaruserid','seminarusername','seminarthumb','seminargallery','seminargallerylinks','seminarindextpl','seminarlisttpl','seminarpagetpl','contentdescribe','contentstatus','contenttemplate','contenttext');
}
?>
