<?php
/*
 * Created on 2013-5-31
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
class config_course
{
	public $fields = array('courseid','coursetitle','coursecsid','coursethumb','courseuserid','coursemoduleid','courseinputtime','coursemodifytime','coursesequence','coursedescribe');
}
?>
