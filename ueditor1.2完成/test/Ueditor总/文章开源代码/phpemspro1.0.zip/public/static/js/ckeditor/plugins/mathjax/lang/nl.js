/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'nl', {
	title: 'Wiskunde in TeX',
	button: 'Wiskunde',
	dialogInput: 'Typ hier uw TeX',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX documentatie',
	loading: 'laden...',
	pathName: 'wiskunde'
} );
