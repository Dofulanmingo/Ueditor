/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'fr', {
	fontSize: {
		label: 'Taille',
		voiceLabel: 'Taille de police',
		panelTitle: 'Taille de police'
	},
	label: 'Police',
	panelTitle: 'Style de police',
	voiceLabel: 'Police'
} );
