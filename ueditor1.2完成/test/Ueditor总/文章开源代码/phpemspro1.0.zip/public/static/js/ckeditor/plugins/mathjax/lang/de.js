/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'de', {
	title: 'Mathematik in Tex',
	button: 'Rechnung',
	dialogInput: 'Schreiben Sie hier in Tex',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX-Dokumentation',
	loading: 'Ladevorgang...',
	pathName: 'rechnen'
} );
